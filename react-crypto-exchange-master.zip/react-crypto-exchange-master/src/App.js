import Navigation from './navigation/Navigation';

const App = () => <Navigation />;

export default App;
